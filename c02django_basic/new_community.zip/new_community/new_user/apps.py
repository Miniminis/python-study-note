from django.apps import AppConfig


class NewUserConfig(AppConfig):
    name = 'new_user'
